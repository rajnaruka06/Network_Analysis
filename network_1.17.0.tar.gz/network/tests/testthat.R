library(testthat)
library(network)

test_check("network")
